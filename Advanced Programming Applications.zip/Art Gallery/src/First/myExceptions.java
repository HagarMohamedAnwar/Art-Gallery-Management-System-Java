package First;

public class myExceptions extends Exception{
	public myExceptions()
	{
		super("Password length must be 8 or more");
	}
}
